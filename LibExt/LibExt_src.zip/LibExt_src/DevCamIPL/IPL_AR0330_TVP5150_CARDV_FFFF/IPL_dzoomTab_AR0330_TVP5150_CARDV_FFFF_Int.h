#ifndef IPL_DZOOMTAB_AR0330_TVP5150_CARDV_FFFF_INT_H_
#define IPL_DZOOMTAB_AR0330_TVP5150_CARDV_FFFF_INT_H_
/**
    IPL_dzoomTabAR0330_TVP5150_CARDV_FFFF_Int.h


    @file       IPL_dzoomTabAR0330_TVP5150_CARDV_FFFF_Int.h
    @ingroup    mISYSAlg
    @note       Nothing (or anything need to be mentioned).

    Copyright   Novatek Microelectronics Corp. 2011.  All rights reserved.
*/


UINT32* SenMode2Tbl(IPL_PROC_ID id,UINT32 SenMode, UINT32 *DzMaxidx);
#endif //IPL_DZOOMTAB_AR0330_TVP5150_CARDV_FFFF_INT_H_

