#ifndef _MENUPHOTO_H
#define _MENUPHOTO_H

extern TM_MENU gPhotoMenu;

extern TM_OPTION gTM_OPTIONS_PHOTO_SIZE[PHOTO_SIZE_ID_MAX];

extern TM_OPTION gTM_OPTIONS_EV[EV_SETTING_MAX];

#endif
