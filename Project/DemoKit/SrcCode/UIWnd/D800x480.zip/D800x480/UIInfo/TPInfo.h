#ifndef _TPINFO_H_
#define _TPINFO_H_

#include "GxInput.h"

extern void     Load_TPInfo(void);
extern void     Save_TPInfo(void);
extern void     Init_TPInfo(void);
extern void     Update_TPInfo(GX_TOUCH_CALI* pTouchCali);

#endif //_TPINFO_H_