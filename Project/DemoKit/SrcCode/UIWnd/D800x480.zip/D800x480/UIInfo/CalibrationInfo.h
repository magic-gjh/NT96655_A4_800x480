#ifndef _CALIBRATIONINFO_H_
#define _CALIBRATIONINFO_H_

//Cal Info
extern void     Load_CalInfo(void);
extern void     Save_CalInfo(void);

#endif //_CALIBRATIONINFO_H_